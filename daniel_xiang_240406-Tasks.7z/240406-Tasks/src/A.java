import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class A {
	public static ArrayList<Integer> q1(ArrayList<Integer> l) {
		return (ArrayList<Integer>) l.stream().filter((n) -> n%2==1).collect(Collectors.toList());
	}

	public static ArrayList<String> q2(ArrayList<String> l) {
		return (ArrayList<String>) l.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
	}
	
	public static int q3(ArrayList<Integer> l) {
		return l.stream().reduce(0, (i, k) -> i+k);
	}
	
	public static Set<Integer> q4(ArrayList<Integer> l) {
		//Write a Java program that uses the Stream API to collect all distinct elements from a list of integers into a set.
		//return l.stream().distinct().collect(Collectors.toSet());
		return l.stream().collect(Collectors.toSet());
	}
	
	public static ArrayList<String> q5(ArrayList<String> l) {
		//Write a Java program that uses the Stream API to filter a list of strings that start with the letter "A" and collect them into a list.
		return (ArrayList<String>) l.stream().filter(n -> n.charAt(0)=='A').collect(Collectors.toList());
	}
	
	public static int q6(ArrayList<Integer> l) {
		//Write a Java program that uses the Stream API to find the maximum value in an array of integers.
		return l.stream().reduce(l.get(0), (i,k) -> Math.max(i, k));
	}
	
	public static ArrayList<String> q7(ArrayList<String> l) {
		//Write a Java program that uses the Stream API to sort a list of strings alphabetically.
		return (ArrayList<String>) l.stream().sorted().collect(Collectors.toList());
	}
	
	public static float q8(ArrayList<Integer> l) {
		//Write a Java program that uses a parallel stream to process a large list of integers and find their average.
		return l.parallelStream().reduce(0, (i,k) -> i+k)/(float)l.size();
	}
	
/*
	public static ArrayList<Person> q9(ArrayList<Person> l) {
		class sortByAge implements Comparator<Person> {

			@Override
			public int compare(Person o1, Person o2) {
				// TODO Auto-generated method stub
				return o1.getAge()-o2.getAge();
			}
			
		}
		return (ArrayList<Person>) l.stream().sorted(new sortByAge()).collect(Collectors.toList());
	}
*/
	public static ArrayList<Person> q9(ArrayList<Person> l) {
		//Write a Java program that uses the Stream API to filter a list of Person objects (having fields name and age) to find all people older than 25.
		return (ArrayList<Person>) l.stream().filter(p -> p.getAge()>25).collect(Collectors.toList());
	}

	public static Map<Integer, List<Person>> q10(ArrayList<Person> l) {
		//Write a Java program that uses the Stream API to group a list of Person objects by age.
		return (Map<Integer, List<Person>>) l.stream().collect(Collectors.groupingBy(p -> p.getAge()));
	}
	
	public static Map<Boolean, List<Integer>> q11(ArrayList<Integer> l) {
		//Write a Java program that uses the Stream API to partition a list of integers into odd and even numbers.
		return (Map<Boolean, List<Integer>>) l.stream().collect(Collectors.partitioningBy(n -> n%2==0));
	}
	public static String q12(List<String> l) {
		//Write a Java program that uses the Stream API to join a list of strings with a comma separator.
		return l.stream().map(Object::toString).collect(Collectors.joining(","));
		//return l.stream().reduce("", (a,b) -> a+","+b);
	}
	public static List<Integer> q13(ArrayList<ArrayList<Integer>> l) {
		//Write a Java program that uses the Stream API to flatten a list of lists of integers into a single list of integers.
		return l.stream().flatMap(Collection::stream).toList();
	}
	public static void q14(List<Integer> l) {
		//Write a Java program that uses the Stream API to find the average, maximum, and minimum values of a list of integers.
		System.out.println("Q14:");
		float avg = q8((ArrayList<Integer>)l);
		int max = q6((ArrayList<Integer>)l);
		int min = l.stream().reduce(l.get(0), (i,k) -> Math.min(i, k));
		System.out.println("  avg: "+avg);
		System.out.println("  max: "+max);
		System.out.println("  min: "+min);
	}
	public static Stream<Integer> q15(int n) {
		//Write a Java program that uses the Stream API to generate a stream of 10 (n) random integers.
		Stream.Builder<Integer> s = Stream.builder();
		Random r = new Random();
		for (int i=0; i<n; i++) {
			s.add(r.nextInt(100));
		}
		return s.build();
	}
	public static List<Integer> q16(int n) {
		//Write a Java program that uses the Stream API to generate an infinite stream of integers starting from 1 and find
		//the first n prime numbers 
		ArrayList<Integer> primes = new ArrayList<Integer>();
		Stream.iterate(1,x->x+1);
		
	}

	public static void main(String[] args) {
		//Write a Java program that uses the Stream API to filter out all even numbers from a list of integers.
		Random r = new Random();
		ArrayList<Integer> l = new ArrayList<Integer>();
		for (int i=0; i<20; i++) {
			l.add(r.nextInt(100));
		}
		System.out.println(l);
		
		ArrayList<String> l2 = new ArrayList<String>();
		l2.add("A");
		l2.add("quick");
		l2.add("brown");
		l2.add("fox");
		l2.add("jumps");
		l2.add("over");
		l2.add("the");
		l2.add("lazy");
		l2.add("dog.");
		System.out.println(l);
		
		ArrayList<Person> l3 = new ArrayList<Person>();
		for (int i=0; i<20; i++) {
			l3.add(new Person(r.nextInt(100)));
		}
		System.out.println(l3);
		
		ArrayList<ArrayList<Integer>> l4 = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> temp;
		for (int i=0; i<4; i++) {
			temp = new ArrayList<Integer>();
			for (int k=0; k<4; k++) {
				temp.add(r.nextInt(100));
			}
			l4.add(temp);
		}
		System.out.println(l4);
		
		
		//ArrayList<Integer> new_l = (ArrayList<Integer>) l.stream().filter((n) -> n%2==1).collect(Collectors.toList());
		System.out.println("Q1: "+q1(l));
		System.out.println("Q2: "+q2(l2));
		System.out.println("Q3: "+q3(l));
		System.out.println("Q4: "+q4(l));
		System.out.println("Q5: "+q5(l2));
		System.out.println("Q6: "+q6(l));
		System.out.println("Q7: "+q7(l2));
		System.out.println("Q8: "+q8(l));
		ArrayList<Person> test = q9(l3);
		System.out.println("Q9: "+test);
		/*for (Person p : test) {
			System.out.println("  "+p.getAge());
		}*/
		Map<Integer, List<Person>> test2 = q10(l3);
		System.out.println("q10: "+test2);
		for (int i : test2.keySet()) {
			System.out.println("  "+test2.get(i));
			for (Person p : test2.get(i)) {
				System.out.println("    "+p.getAge());
			}
		}
		Map<Boolean, List<Integer>> test3 = q11(l);
		System.out.println("q11: "+test3);
		for (boolean i : test3.keySet()) {
			System.out.println("  "+test3.get(i));
			for (Integer k : test3.get(i)) {
				System.out.println("    "+k);
			}
		}
		System.out.println("Q12: "+q12(l2));////////////////////
		System.out.println("Q13: "+q13(l4));
		q14(l);
		System.out.println("Q15: "+q15(10).collect(Collectors.toList()));
		
	}

}
