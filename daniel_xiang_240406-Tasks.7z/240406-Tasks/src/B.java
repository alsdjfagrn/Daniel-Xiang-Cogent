import java.util.ArrayList;
import java.util.stream.Collectors;

public class B {

	public static ArrayList<String> q2(ArrayList<String> l) {
		return (ArrayList<String>) l.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
	}
	
	
	public static void main(String[] args) {
		//Write a Java program that uses the Stream API to convert a list of strings to uppercase.
		ArrayList<String> l = new ArrayList<String>();
		l.add("the");
		l.add("quick");
		l.add("brown");
		l.add("fox");
		l.add("jumps");
		l.add("over");
		l.add("the");
		l.add("lazy");
		l.add("dog.");
		System.out.println(l);
		
		System.out.println(q2(l));
	}

}
