import java.util.ArrayList;
import java.util.Random;

public class C {

	public static int q3(ArrayList<Integer> l) {
		return l.stream().reduce(0, (i, k) -> i+k);
	}
	
	public static void main(String[] args) {
		//Write a Java program that uses the Stream API to find the sum of all elements in a list of integers.
		Random r = new Random();
		ArrayList<Integer> l = new ArrayList<Integer>();
		for (int i=0; i<20; i++) {
			l.add(r.nextInt(100));
		}
		System.out.println(l);
		
		System.out.println(q3(l));
	}

}
