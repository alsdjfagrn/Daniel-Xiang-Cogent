import java.util.Scanner;

public class A {
//	Write a Java program to find the factorial of a given number.
	static int factorial(int n) {
		if (n>2) {
			return n * factorial(n-1);
		}
		return 2;
	}
	
//	Write a Java program to check whether a number is prime or not.
	static boolean isPrime(int n) {
		for (int i=2; i<n/2; i++) {
			if (n%i==0) {
				return false;
			}
		}
		return true;
	}
	
//	Write a Java program to print the Fibonacci series up to a given number.
	static void fib(int limit) {
		int a = 0;
		int b = 0;
		int curr = 1;
		
		//Sum of two preceding nums in seq
		do {
			System.out.println(curr);
			a = b;
			b = curr;
			curr = a + b;
		} while (curr < limit); 
	}
//	Write a Java program to check if a string is a palindrome.
	static boolean isPalindrome(String s) {
		s = s.toUpperCase();
		for (int i=0; i<s.length(); i++) {
			if (s.charAt(i) != s.charAt(s.length()-1-i)) {
				return false;
			}
		}
		return true;
	}
	
//	Write a Java program to reverse a string./////////////////////////////////////////////////////////////////
	static String reverseString(String s) {
		StringBuilder sb = new StringBuilder(s);
		char temp; 
		for (int i=0; i<sb.length()/2; i++) {
			temp = sb.charAt(i);
			sb.setCharAt(i, sb.charAt(sb.length()-1-i));
			sb.setCharAt(sb.length()-1-i, temp);
		}
		return sb.toString();
	}
	
//	Write a Java program to check whether a year is a leap year or not.
	static boolean isLeapYear(int year) {
		if ((year%100==0 && year%400==0) || (year%4==0)) {
			return true;
		}
		return false;
	}
	
//	Write a Java program to sort an array of integers using bubble sort.

	static int[] bs(int[] arr) {
		boolean sorted;
		int temp;
		do {
			sorted = true;
			for (int i=0; i<arr.length-2; i++) {
				if (arr[i] > arr[i+1]) {
					temp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = temp;
					sorted = false;
				}
			}
		} while (sorted != true);
		return arr;
	}

//	Write a Java program to calculate the average grade of students and determine the highest and lowest grades.
	static void avgAndRange(float[] grades) {
		float max = grades[0];
		float min = grades[0];
		float sum = 0;
		
		for (float g : grades) {
			if (g > max) {
				max = g;
			}
			if (g < min) {
				min = g;
			}
			sum += g;
		}

		System.out.println("Max: "+max);
		System.out.println("Min: "+min);
		System.out.println("Average grade: "+sum/grades.length);
	}
	
//	Write a Java program to multiply two matrices.
	/*
	static float dotProduct(float[] a, float[] b) {
		float dp = 0;
		for (int i=0; i<a.length; i++) {
			dp+=(a[i]*b[i]);
		}
		return dp;
	}
	static float[] getRow(float[][] matrix, int rowNum) {
		return matrix[rowNum];
	}
	static float[] getCol(float[][] matrix, int colNum) {
		
		System.out.println("colNum: "+colNum);
		for (float[] r : matrix) {
			for (float f : r) {
				System.out.print(f+" ");
			}
			System.out.println();
		}
		
		float[] newRow = new float[matrix.length];
		for (int i=0; i<matrix.length; i++) {
			newRow[i] = matrix[i][colNum];
		}
		return newRow;
	}
	static float[][] matrixMult(float[][] a, float[][] b) {
		float[] bCol;
		float[][] newMatrix = new float[a.length][b.length];
		for (int i=0; i<a.length; i++) {
			for (int k=0; k<b.length; k++) {
				newMatrix[i][k] = dotProduct(getRow(a, i), getCol(b, k));
			}
		}
		return newMatrix;
	}
	*/
	
//	Create a Java class to manage a bank account with functionalities to deposit, withdraw, and check balance.
//		See BankAccount.java
	
//	Create a Java program to manage employees with functionalities to add, remove, and display employee details.

//	Write a Java program to create a simple calculator using switch case statements.
	static void calc() {
		int choice = -1;
		int a;
		int b;
		Scanner s = new Scanner(System.in);
		while (choice != 5) {
			switch (choice) {
				case 1:
					System.out.println("Adding");
					System.out.print("a: ");
					a = s.nextInt();
					System.out.print("b: ");
					b = s.nextInt();
					System.out.println(a+b);
					break;
				case 2:
					System.out.println("Subtracting");
					System.out.print("a: ");
					a = s.nextInt();
					System.out.print("b: ");
					b = s.nextInt();
					System.out.println(a-b);
					break;
				case 3:
					System.out.println("Multiplying");
					System.out.print("a: ");
					a = s.nextInt();
					System.out.print("b: ");
					b = s.nextInt();
					System.out.println(a*b);
					break;
				case 4:
					System.out.println("Dividing");
					System.out.print("a: ");
					a = s.nextInt();
					System.out.print("b: ");
					b = s.nextInt();
					System.out.println(a/b);
					break;
				case 5:
					System.out.println("Quitting");
					break;
				default:
					System.out.println("Invalid");
			}
		}
		return;
	}
	
	
//	Write a Java program to implement the binary search algorithm for a sorted array.
	static int binSearch(int[] sortedArr, int val) {
		System.out.println("binSearch()");
		int currMin = 0;
		int currMax = sortedArr.length-1;
		int i;
		int n;
		
		while (currMin <= currMax) {
			//Check middle value
			i = (currMax+currMin)/2;
			n = sortedArr[i];
			System.out.println("  "+currMin+" "+currMax+" "+n+" "+val);
			//Use middle val. to decide which half to search
			if (n==val) {
				return i;
			}
			else {
				if (n<val) {
					currMin = i+1;
				}
				else {//n>val
					currMax = i-1; 
				}
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {9,8,7,6,435,26,6,-1,5,4,3,2,1,0};
		float[] arr2 = {
				11.1f,22.2f,33.3f,44.4f,55.5f,66.6f,77.7f,88.8f,99.9f,00.0f
		};
		
		System.out.println(factorial(5));
		System.out.println(isPrime(29));
		fib(100);
		System.out.println(isPalindrome("raCecAr"));
		System.out.println(reverseString("qwertyuiop[]"));
		arr = bs(arr);
		for (int i:arr) {
			System.out.println(i);
		}
		avgAndRange(arr2);
		
		/*
		float[][] A = {
				{1,2,3,4},
				{5,6,7,8},
				{9,10,11,12}
		};
		float[][] B = {
				{1,2,3},
				{4,5,6},
				{7,8,9},
				{10,11,12}
		};
		float[] v = getCol(B, 0);
		for (float f:v) {
			System.out.println(f);
		}
		float[][] C = matrixMult(A, B);
		for (float[] r : C) {
			for (float f : r) {
				System.out.print(f+" ");
			}
			System.out.println();
		}
		*/
		int[] arr3 = {0,1,2,3,4,5,6,7,8,9,10,11,22,33,44,55,66,77,88,99};
		System.out.println(binSearch(arr3, 99));
	}

}
