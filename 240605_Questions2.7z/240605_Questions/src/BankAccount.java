
public class BankAccount {
	float balance = 0;
	//deposit, withdraw, and check balance
	void deposit(float num) {
		balance += num;
	}
	boolean withdraw (float num) {
		if (num > balance) {
			return false;
		}
		num -= balance;
		return true;
	}
	float checkBalance() {
		System.out.println("Balance: "+balance);
		return balance;
	}
}
