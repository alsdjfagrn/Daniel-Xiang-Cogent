import java.util.Arrays;
import java.util.List;

public class LB_Wildcard {
	//Accepts superclass of Integer?
	void printData(List<? super Integer> data) {
		for (Object o : data) {
			System.out.println(o);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LB_Wildcard x = new LB_Wildcard();

		List<Number> al = Arrays.asList(1, 2, 32.3, 334, 214124641);
		x.printData(al);
		
	}

}
