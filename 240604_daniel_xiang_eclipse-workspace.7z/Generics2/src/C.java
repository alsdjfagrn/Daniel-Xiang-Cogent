//Unbounded Wildcard

import java.util.List;
import java.util.Arrays;

public class C {
	
	void printData(List<?> data) {
		for (Object o : data) {
			System.out.println(o);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c = new C();

		List<Integer> al = Arrays.asList(12, 13, 14);
		c.printData(al);
		
		List<String> al2 = Arrays.asList("qwer", "asdf", "zxcv");
		c.printData(al2);
	}

}
