import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class A {
	
	<E> void printData (List<E> data) {
		for (E o : data) {
			System.out.println(o);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A o = new A();
		List data = Arrays.asList("Millan", "Rohan", "Jordan", "Ravi", 23);
		o.printData(data);
	}

}
