
public class Trainer extends Student{
	
	//Overriding
	void login(String username, String password) {
		System.out.println("Trainer.login()");
	}
	
	//Overloading
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s = new Student();
		s.login("student@gmail.com", "123");
		
		Trainer t = new Trainer();
		t.login("Trainer@gmail.com", "zxc");
	}

}
