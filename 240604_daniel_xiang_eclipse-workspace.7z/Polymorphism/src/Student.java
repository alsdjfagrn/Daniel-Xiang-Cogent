
public class Student {	
	void login(String username, String password) {
		System.out.println("Student.login()");
	}
}
