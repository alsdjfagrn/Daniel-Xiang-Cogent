import java.util.Scanner;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int age;
		
		Scanner s = new Scanner(System.in);
		System.out.print("enter your age: ");
		age = s.nextInt();
		
		if (age >= 18) {
			System.out.println("You can vote");
		}
		else {
			throw new Exception("You can't vote");
		}
		
	}

}
