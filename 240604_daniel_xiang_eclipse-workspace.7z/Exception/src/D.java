import java.util.Scanner;

public class D {

	String checkStatus(int age) {
		return age>=18?"Can vote":"Can't vote";
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D o = new D();
		Scanner s = new Scanner(System.in);
		System.out.print("Enter age: ");
		int age = s.nextInt();
		String result = o.checkStatus(age);
		
		if (result.equals("Can't vote")) {
			try {
				throw new Exception("Can't vote");
			}
			catch (Exception e) {
				System.out.println("Program executes again");
				main(args);
			}
		}
		else {
			System.out.println(result);
		}
	}

}
