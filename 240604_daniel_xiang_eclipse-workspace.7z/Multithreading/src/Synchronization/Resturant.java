package Synchronization;

public class Resturant extends Thread {
	
	static int stock = 3;
	
	//Need to stop other threads once this line starts until the if-branch is finished
	//synchronized void order() {
	synchronized void order() {
		if (stock > 0) {
			System.out.println(Thread.currentThread().getName()+" placed order ("+stock+" left)");
			stock--;
		}
		else {
			System.out.println("Out of stock");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num_r = 30;
		Resturant r = new Resturant();
		Thread[] c = new Thread[num_r];
		for (int i=0; i<num_r; i++) {
			c[i] = new Thread(r);
			c[i].setName("Customer #"+String.valueOf(i));
		}
		
		for (Thread customer:c) {
			customer.start();
		}
		System.out.println("Final stock: "+stock);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		//Asynchronous stuff here
		
		
		//Synchronous stuff here
		synchronized (this) {
			order();
		}
	}
}
