package Multithreading3;

public class Calculator {
	void series1() {
		for (int i=0; i<10; i++) {
			System.out.println("series1(): "+(i));
		}
	}
	void series2() {
		for (char a='A'; a<'J'; a++) {
			System.out.println("series2(): "+(a));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator cal = new Calculator();

		Thread t1 = new Thread() {
			public void run() {
				cal.series1();
			}
		};
		t1.setName("ABC");
		
		
		
		Runnable run = () -> {
			cal.series2();
		};
		Thread t2 = new Thread(run);
		t2.setName("XYZ");
		
		
		
		t1.start();
		t2.run();
	}
}
