package predefinedThreadMethods;

public class Calculator extends Thread {
	void series1() {
		for (int i=0; i<10; i++) {
			System.out.println("series1(): "+(i));
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void series2() {
		for (char a='A'; a<'J'; a++) {
			System.out.println("series2(): "+(a));
		}
	}
	
	void support() {
		for (int i=0; i<100000; i++) {
			System.out.println(i+" support()");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Calculator cal1 = new Calculator();
		cal1.setName("Chris");
		Calculator cal2 = new Calculator();
		cal2.setName("Zaynab");

		
		//Run threads
		cal1.start();
		//cal1.join();//Wait until thread in cal1 is done
		cal2.start();
		
		
		Calculator cal3 = new Calculator();
		cal3.setName("Support");
		cal3.setDaemon(true);//Daemon threads are designed to support a main thread; execute only as a main thread executes & stops when the main one does.
		cal3.start();
		
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (Thread.currentThread().getName().equals("Chris")) {
			series1();
		}
		if (Thread.currentThread().getName().equals("Zaynab")) {
			series2();
		}
		if (Thread.currentThread().getName().equals("Support")) {
			support();
		}
	}
}
