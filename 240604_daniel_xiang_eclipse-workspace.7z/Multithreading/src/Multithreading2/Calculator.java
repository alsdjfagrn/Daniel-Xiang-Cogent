package Multithreading2;

public class Calculator implements Runnable {
	
	void series1() {
		for (int i=0; i<10; i++) {
			System.out.println("series1(): "+(i));
		}
	}
	void series2() {
		for (char a='A'; a<'J'; a++) {
			System.out.println("series2(): "+(a));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator cal = new Calculator();

		Thread t1 = new Thread(cal);
		t1.setName("Chris");
		Thread t2 = new Thread(cal);
		t2.setName("Zaynab");
		
		t1.start();
		t2.start();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (Thread.currentThread().getName().equals("Chris")) {
			series1();
		}
		if (Thread.currentThread().getName().equals("Zaynab")) {
			series2();
		}
	}
}
