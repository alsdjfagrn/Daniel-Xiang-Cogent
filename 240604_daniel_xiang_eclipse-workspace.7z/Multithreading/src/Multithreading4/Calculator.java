package Multithreading4;

public class Calculator {
	void series1() {
		for (int i=0; i<10; i++) {
			System.out.println("series1(): "+(i));
		}
	}
	void series2() {
		for (char a='A'; a<'J'; a++) {
			System.out.println("series2(): "+(a));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator cal = new Calculator();

		Runnable r1 = () -> {
			cal.series1();
		};
		Thread t1 = new Thread(r1);
		
		Runnable r2 = () -> {
			cal.series2();
		};
		Thread t2 = new Thread(r2);
		
		t1.start();
		t2.start();
	}
}
