
public class Calculator extends Thread {
	void sum(int a, int b) {
		System.out.println("sum("+(a)+","+(b)+"): "+(a+b));
	}
	void sub(int a, int b) {
		System.out.println("sub("+(a)+","+(b)+"): "+(a-b));
	}
	
	void series(int a, int b) throws Exception {
		System.out.println("series("+(a)+","+(b)+"): ");
		for (int i=a; i<b; i++) {
			if (i==5) {
				throw new Exception("5 reached in series()");
			}
			System.out.print((i)+", ");
		}
		System.out.println(b);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if (currentThread().getName().equals("Meti")) {
			try {
				series(1,10);
			}
			catch (Exception e) {
				System.out.println("Found exception: "+(e));
			}
		}
		if (currentThread().getName().equals("Roberto")) {
			sum(1,10);
		}
		if (currentThread().getName().equals("Jordan")) {
			sub(1,10);
		}
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		/*
		Calculator cal = new Calculator();
		cal.sum(12, 20);
		cal.sub(23, 12);
		//cal.series(1, 10);
		*/
		
		Calculator c1 = new Calculator();
		c1.setName("Meti");
		Calculator c2 = new Calculator();
		c1.setName("Roberto");
		Calculator c3 = new Calculator();
		c1.setName("Jordan");
		
		//c1.start();
		c2.start();
		c3.start();
	}

}
