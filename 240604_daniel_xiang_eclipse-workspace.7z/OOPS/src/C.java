
public class C {

	{
		//init block
		//Executed on object creation
		System.out.println("init block");
	}
	
	C() {
		System.out.println("Constructor");
	}
	
	void welcome() {//Not static; needs object to call
		System.out.println("Welcome to OOPS Concepts");
	}

	void sum(int a, int b) {
		System.out.println(a+b);
	}
	void sub(int a, int b) {
		System.out.println(a-b);
	}
	void multi(int a, int b) {
		System.out.println(a*b);
	}
	void bio(String name, int age, float exp) {
		System.out.println(name+" "+age+" "+exp);
	}
	void checkEvenOdd(int num) {
		System.out.println(num%2==0?"Even":"Odd");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c = new C();//Assign new object to reference
		c.welcome();
		c.sum(8, 9);
		c.sub(1,  3);
		c.multi(12, 12);
		c.bio("Ravi", 29, 9.5f);
		c.checkEvenOdd(123754816);
	}

}
