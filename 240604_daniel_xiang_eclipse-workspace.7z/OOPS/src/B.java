
public class B {
	
	B() {
		this('A');//Execute current class constructor with parameter 'A'
		System.out.println("Constructor without arg");
	}
	B(char c) {
		this(89.23f);
		System.out.println("char is "+c);
	}
	B(float p) {
		System.out.println("p has "+p);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new B();
	}

}
