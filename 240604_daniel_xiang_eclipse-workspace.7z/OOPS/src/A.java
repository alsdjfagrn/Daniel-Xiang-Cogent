
public class A {
	static {
		System.out.println("Static block");
		System.out.println("Automatically executed after(?) main method");
	}
	
	static {
		System.out.println("Second static block");
	}
	
	static void welcome() {
		System.out.println("Static method");
	}

	A() {
		//Constructor
		System.out.println("Constructor");
	}
	A(int p) {
		//Constructor
		System.out.println("Constructor 2");
	}
	A(int p, int q) {
		//Constructor
		System.out.println("Constructor 3");
	}
	A(boolean check) {
		//Constructor
		System.out.println("Constructor bool");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println("Main code");
			welcome();
			new A(1, 2);//Execute constructor after creating class
	}

}
