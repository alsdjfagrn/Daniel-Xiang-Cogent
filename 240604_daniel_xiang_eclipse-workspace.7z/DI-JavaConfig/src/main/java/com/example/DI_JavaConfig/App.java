package com.example.DI_JavaConfig;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {
    public static void main( String[] args ) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Book b = context.getBean(Book.class);
   		System.out.println(b.getName());
   		
   		Address a = context.getBean(Address.class);
   		System.out.println(a.getCity()+", "+a.getCountry());
   		
   		Person p = context.getBean(Person.class);
   		System.out.println(p.getName());

   		School s1 = (School)context.getBean("sch1");
   		School s2 = (School)context.getBean("sch2");
   		
   		//Autowiring
   		Education e = context.getBean(Education.class);
   		e.getSchool().message();
    }
}
