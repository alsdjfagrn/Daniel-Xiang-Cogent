package com.example.DI_JavaConfig;

public class School {
	public School() {
		System.out.println("School()");
	}
	
	void message() {
		System.out.println("Education.message()");
	}
}
