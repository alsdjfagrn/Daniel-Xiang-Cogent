package com.example.DI_JavaConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages="com.example.DI_JavaConfig")
public class AppConfig {
	AppConfig() {
		System.out.println("AppConfig() - Objects created");
	}
	
	@Bean
	public Book book() {
		Book b = new Book();
		b.setName("asdf");
		return b;
	}
	
	@Bean
	public Address address() {
		return new Address("New York", "USA");
	}
	
	@Bean
	public Person person() {
		Person p = new Person();
		p.setName("qwer");
		return p;
	}
	
	//Prototype creates object each time?
	@Bean(name= {"sch1"})
	@Scope("prototype")
	@Primary
	public School school() {
		System.out.println("AppConfig.school()");
		return new School();
	}
	@Bean(name= {"sch2"})
	@Scope("prototype")
	public School school2() {
		System.out.println("AppConfig.school2()");
		return new School();
	}
}
