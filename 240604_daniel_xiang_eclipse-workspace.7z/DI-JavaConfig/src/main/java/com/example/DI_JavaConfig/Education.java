package com.example.DI_JavaConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Education {
	@Autowired
	private School school;

	public School getSchool() {
		return school;
	}
	public void setSchool(School school) {
		this.school = school;
	}
}
