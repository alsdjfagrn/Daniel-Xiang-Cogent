
public class WrapperClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer i = 90;
		Float f = 34.45f;
		Double d = 23.34;
		
		Integer[] i2 = {23,34,45,56,67};
		for (Integer p:i2) {
			System.out.println(p);
		}
	}
}
