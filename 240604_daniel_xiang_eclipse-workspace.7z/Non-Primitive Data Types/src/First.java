
public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Non-primitive data types
		/* Object
		 * String (immutable)
		 * */
		
		//StringBuilder & StringBuffer (mutable)
		//String name = "Rohit";
		//String name2 = "Jordan";
		//String name3 = new String("Jonathan");//Create new object
		//StringBuilder sb = new StringBuilder("Meti");
		//StringBuilder sb2 = new StringBuilder("Meti");
		
		//StringBuilder sb = new StringBuilder("Meti");
		StringBuffer sb = new StringBuffer("Meti");
		System.out.println(sb);
		sb.append(" is a Java developer.");//StringBuilder class is mutable
		System.out.println(sb);
		System.out.println(sb.length());
		System.out.println(String.valueOf(sb).toUpperCase());
		System.out.println(sb.charAt(0));
		System.out.println(sb.indexOf("Meti"));
		System.out.println(sb.indexOf("is"));
		System.out.println(sb.indexOf("Z"));
		System.out.println(sb.isEmpty());
		sb.delete(4,  sb.length());
		System.out.println(sb+" "+sb.length());
		System.out.println(sb.substring(2));
		System.out.println(sb.reverse());
		
		String n = "Dalton";
		StringBuilder sb3 = new StringBuilder(n);
		System.out.println(sb3.reverse());
		

		//System.out.println(String.valueOf(sb)==String.valueOf(sb2));
		
		
		//Arrays
		String[] names = {"Aman", "Shreya", "Anvar", "Roberto"};
		int[] nums = {0,1,2,3,4,5,6,7,8,9};
		System.out.println(names[0]);
		nums[0] = 90;
		System.out.println(nums[0]);
		for (int i=0; i<nums.length; i++) {
			System.out.println(nums[i]);
		}
		for (int p:nums) {//for int p in nums
			System.out.println(p);
		}
	}

}
