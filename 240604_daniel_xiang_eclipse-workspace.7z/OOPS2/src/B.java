
public class B {
	
	void multi(int a, int b) {
		System.out.println("Product is "+(a*b));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b = new B();
		b.multi(23, 20);
	}

}
