
public class A {
	
	void sum(int a, int b) {
		System.out.println("Sum is "+(a+b));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		a.sum(12, 10);
		
		B b = new B();
		b.multi(23, 20);
		
		C c = new C();
		c.checkEven(15825382);
	}

}
