
public class C {
	
	void checkEven(int num) {
		System.out.println(num%2==0?"Even":"Odd");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c=new C();
		c.checkEven(23);
	}

}
