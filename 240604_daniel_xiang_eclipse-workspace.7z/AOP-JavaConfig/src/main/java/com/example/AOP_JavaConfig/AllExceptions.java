package com.example.AOP_JavaConfig;

public class AllExceptions {

}
