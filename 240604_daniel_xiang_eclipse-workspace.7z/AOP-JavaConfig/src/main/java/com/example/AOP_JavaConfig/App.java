package com.example.AOP_JavaConfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import IOC.A;

public class App {
    public static void main( String[] args ) throws InterruptedException {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        AllLogging log = context.getBean(AllLogging.class);
        log.message1();
        log.message2();
        log.series();
        
        //A a = new A();
        //a.m1();
    }
}
