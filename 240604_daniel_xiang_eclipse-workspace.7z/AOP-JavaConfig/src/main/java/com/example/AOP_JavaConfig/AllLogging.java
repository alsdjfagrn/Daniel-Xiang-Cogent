package com.example.AOP_JavaConfig;
//Logging


//Join points
public class AllLogging {
	public void message1() {
		System.out.println("AllLogging.message1()");
	}
	public void message2() {
		System.out.println("AllLogging.message2()");
	}
	public void series() throws InterruptedException {
		System.out.println("AllLogging.series()");
		for (int i=0; i<10; i++) {
			System.out.println("  "+i);
			Thread.sleep(1000);
		}
	}
}
