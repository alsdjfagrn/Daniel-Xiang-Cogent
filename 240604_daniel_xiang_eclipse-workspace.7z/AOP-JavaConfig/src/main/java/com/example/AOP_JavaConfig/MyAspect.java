package com.example.AOP_JavaConfig;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	
	//Before(<function path>)
	@Before("execution(* com.example.AOP_JavaConfig.AllLogging.message1())")
	public void first() {
		System.out.println("MyAspect.first() - Start before logic");
	}
	
	@After("execution(* com.example.AOP_JavaConfig.AllLogging.message2())")
	public void end() {
		System.out.println("MyAspect.end() - Start after logic");
	}
	
	@Around("execution(* com.example.AOP_JavaConfig.AllLogging.series())")
	public void runningCode(ProceedingJoinPoint jp) throws Throwable {
		System.out.println("MyAspect.runningCode() - Working with logic");
		jp.proceed();//Runs method at joinpoint
		for (int i=0; i<10; i++) {
			System.out.println("  Working with logic - "+i);
		}
	}
	
	/*@Around("execution(*IOC.A.m1())")
	public void runningCode2(ProceedingJoinPoint jp) throws Throwable {
		System.out.println("MyAspect.runningCode2() - Working with logic");
		jp.proceed();//Runs method at joinpoint
		System.out.println("  MyAspect.runningCode2() finished");
	}*/
}
