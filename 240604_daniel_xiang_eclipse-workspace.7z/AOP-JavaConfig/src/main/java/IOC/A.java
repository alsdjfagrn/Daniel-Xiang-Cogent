package IOC;

public class A {
	public A() {
		System.out.println("A()");
	}
	public void m1() {
		System.out.println("A.m1()");
	}
}
