package finalKeyword;

public class D {
	final void sum(int a, int b) {
		
	}
}
