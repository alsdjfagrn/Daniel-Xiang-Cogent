package finalKeyword;

public class A extends D{
	
	//Set value to be constant
	final float pi = 3.14159265f;
	
	//Can't override final
	//final void sum(int a, int b) {
	//	
	//}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A obj = new A();
		
		System.out.println(obj.pi);
		
		B obj2 = new B();
	}

}
