package finalKeyword;

public final class B { //Final classes can't be inherited

}
