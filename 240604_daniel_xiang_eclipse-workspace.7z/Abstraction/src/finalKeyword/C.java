package finalKeyword;

final public abstract class C { //Final & abstract conflict

}
