package accessModifier2;

public class C {
	private int p = 23;
	protected int q = 34;
	public int r = 90;
	int s = 56;
}
