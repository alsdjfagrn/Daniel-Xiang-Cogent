package exampleInterface;

public interface B {
	int num = 23;//By default, public static final
	
	void paymentMode();
	void checkCredentials();
	void statusOfPayment();
	
	static void caller() {
		System.out.println("B.caller() - static method from interface");
	}
	
	default void message() { //default method
		System.out.println("B.message() - default modifier");
	}
}
