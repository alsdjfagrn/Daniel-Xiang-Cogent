package exampleInterface;

//If inheriting between similar concepts, use "extends" keyword
//Otherwise, use "implements
public class A implements B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj = new A();
	}

	@Override
	public void paymentMode() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkCredentials() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void statusOfPayment() {
		// TODO Auto-generated method stub
		
	}

}
