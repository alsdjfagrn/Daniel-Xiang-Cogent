package markerInheritance;

public class A implements Cloneable{
	
	
	//"throws" is used to handle runtime exceptions
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		//Cloning
		//	Assigning same object to multiple references
		//	_.clone() returns an object; needs to be cast
		//	Needs to throw Exception to be cloneable
		//	Implements Cloneable?
		A o = new A();
		A o2 = (A)o.clone();
		A o3 = (A)o.clone();
	}

}
