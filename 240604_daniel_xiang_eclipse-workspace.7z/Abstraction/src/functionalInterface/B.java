package functionalInterface;

public interface B {
	public void payment();
}
