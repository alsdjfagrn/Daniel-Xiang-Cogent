package functionalInterface;

public class A {
	public static void main(String[] args) {
		B o = new B() {
			@Override
			public void payment() {
				// TODO Auto-generated method stub
				System.out.println("payment()");
			}
		};
		o.payment();
		
		//lambda expression - only works with functional interfaces
		B o2 = () -> {
			System.out.println("payment()");
		};
		o2.payment();
	}
}
