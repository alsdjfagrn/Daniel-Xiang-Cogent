package accessModifier;

import accessModifier2.C;

public class A extends C{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B obj = new B();
		System.out.println(obj.a);//Private variable; can't access outside class
		System.out.println(obj.b);//Same package
		System.out.println(obj.c);//Public
		System.out.println(obj.d);//Default access modifier in same package
		
		C obj2 = new C();
		System.out.println(obj2.p);//Private variable
		System.out.println(obj2.q);//No inheritance
		System.out.println(obj2.r);
		System.out.println(obj2.s);//Diff package
		
		A obj3 = new A();
		System.out.println(obj3.p);//Private variable
		System.out.println(obj3.q);//Inheritance
		System.out.println(obj3.r);
		System.out.println(obj3.s);//Diff package
	}

}
