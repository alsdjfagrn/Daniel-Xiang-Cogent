package accessModifier;

public class B {
	private int a = 90;
	protected int b = 234;
	public int c = 67;
	int d = 34;
}
