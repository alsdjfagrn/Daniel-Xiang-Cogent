package abstractClass;

public class A extends B {
	
	int num=89;
	
	void message() {
		System.out.println("A.message()");
		System.out.println("  this.num: "+(num));
		System.out.println("  super.num: "+(super.num));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//B obj = new B();
		//Abstract classes can't be used directly; template for class
		//Access abstract classes through inheritance only
		
		A obj = new A();
		obj.message();
		
		obj.caller();
		
		
	}

	@Override
	void sum(int a, int b) {
		System.out.println("A.sum("+(a)+","+(b)+")");
		//Force override
		System.out.println("  "+(a+b));
	}
	@Override
	void sub(int a, int b) {
		System.out.println("A.sub("+(a)+","+(b)+")");
		//Force override
		System.out.println("  "+(a-b));
	}

}
