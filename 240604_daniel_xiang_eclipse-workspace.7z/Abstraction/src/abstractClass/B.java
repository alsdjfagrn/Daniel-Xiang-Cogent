package abstractClass;

public abstract class B {
	
	static {
		System.out.println("Static block (B)");
	}
	
	int num = 1234;
	
	B() {
		System.out.println("B constructor (Abstract)");
	}
	
	void caller() {
		System.out.println("caller()");
	}

	//Abstract method
	abstract void sum(int a, int b);
	//Abstract method
	abstract void sub(int a, int b);
}
