import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> data = Arrays.asList(0,1,2,3,4,5,6,7,8,9);
		
		//Function<Integer, Integer> rnum = (num) -> num+5;
		//data.stream().map(rnum).forEach(System.out::println);
		data.stream().map((num) -> num+5).forEach(System.out::println);
	}

}
