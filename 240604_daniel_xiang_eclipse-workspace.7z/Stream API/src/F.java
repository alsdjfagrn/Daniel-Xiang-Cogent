import java.util.Arrays;
import java.util.List;

public class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> names = Arrays.asList("asdf", "qwer", "zxcv");
		
		String result = names.stream().reduce("",String::concat);
		System.out.println(result);
		
		names.stream().map((n)->n.toUpperCase()).forEach(System.out::println);
		
	}

}
