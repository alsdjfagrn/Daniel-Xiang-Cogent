import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> d = Arrays.asList(1,2,3,4,5);
		Set<Integer> d2 = d.stream().collect(Collectors.toSet());
		d2.stream().forEach(System.out::println);
		
		boolean check = d.stream().allMatch((num) -> num%2==0);
		System.out.println(check);
		
		check = d.stream().anyMatch((num) -> num%2==0);
		System.out.println(check);
	}

}
