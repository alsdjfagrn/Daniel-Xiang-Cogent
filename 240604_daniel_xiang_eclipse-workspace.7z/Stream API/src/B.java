import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;



public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> data = Arrays.asList(0,1,2,3,4,5,6,7,8,9);
		
		Predicate<Integer> p = (num) -> {
			if (num%2==-0) {
				return true;
			}
			return false;
		};

		//data.stream().filter(p).forEach(System.out::println);
		data.stream().filter((num) -> num%2==0).forEach(System.out::println);
		
		
	}

}
