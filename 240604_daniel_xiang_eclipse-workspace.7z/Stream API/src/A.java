import java.util.function.UnaryOperator;
import java.util.stream.Stream;

import java.util.List;
import java.util.stream.Collectors;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnaryOperator<Integer> uni = (num) -> num+1;
		Stream.iterate(10, uni).limit(10).forEach(System.out::println);
		/*
		 * .limit(x) -> Limit to number of executions
		 */
		
		System.out.println();

		Stream.iterate(10, (num) -> num+1)
		.limit(10)
		.forEach(System.out::println);
		
		System.out.println();
		
		Stream.iterate(10, (num) -> num+1)
		.limit(10)
		.collect(Collectors.toList());
		
		List data = Stream.iterate(10, (num) -> num+1).limit(10).collect(Collectors.toList());
		data.stream().forEach(System.out::println);
		data.stream().forEach(a -> System.out.println(a));
		
		
		
	}

}
