package com.example.LooseCoupling_IOC_DI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	/*XML Based Config*/
    	//Interface to inject dependencies
        ApplicationContext  context = new ClassPathXmlApplicationContext("springconfig.xml");//springconfig.xml provides info on what objects spring should create
        //vs bean factory?
        //BF parent
        
        //Fill variable with previously created Book
        Book b = (Book)context.getBean("book");
        b.message();
        
        //Injecting beans
        //Inject Book dependency into School dependency
        //School s = (School)context.getBean("school");
        //School s2 = (School)context.getBean("school2");
        
        //Book b2 = (Book)context.getBean("book3");
        
        //Map-based initialization
        
        Teacher t = (Teacher) context.getBean("teacher");
        System.out.println(t.getName());
        
        //Autowiring
        //	Inject bean automatically
        //		By name
        //		By type
        
    }
}
