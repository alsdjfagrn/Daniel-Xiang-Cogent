package com.example.LooseCoupling_IOC_DI;

import java.util.ArrayList;
import java.util.HashMap;

public class School {
	public School(Book b) {
		System.out.println("School(Book b)");
	}
	public School(HashMap<String, Object> records) {
		System.out.println("School(HashMap<String, Object> records)");
		for (Object key : records.keySet()) {
			System.out.println("  "+key+": "+records.get(key));
		}
	}
	public School(Book b, ArrayList<HashMap<String, Object>> records) {
		System.out.println("School(HashMap<String, Object> records)");
		System.out.print("  ");
		b.message();
		/*
		for (HashMap<String, Object> record : records ) {
			for (Object key : record.keySet()) {
				System.out.println("  "+key+": "+record.get(key));
			}
		}*/
		for (Object o : records) {
			System.out.println("  "+o);
		}
	}
}
