package com.example.LooseCoupling_IOC_DI;

import java.util.ArrayList;

public class Book {//Init book object
	public Book() {
		System.out.println("Book()");
	}
	public Book(ArrayList<String> names) {
		System.out.println("Book(ArrayList<String> names)");
		for (String n:names) {
			System.out.println("  "+n);
		}
	}
	public void message() {
		System.out.println("Book.message()");
	}
}
