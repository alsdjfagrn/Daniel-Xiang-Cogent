
public class Outer {
	
	private int num = 34;
	
	void display() {
		System.out.println("display()");
		class LocalInner {
			void message() {
				System.out.println("  localInner.message()");
				System.out.println("  "+num);
			}
		}
		
		LocalInner li = new LocalInner();
		li.message();
	}
	
	class Inner {
		Inner() {
			System.out.println("Inner()");
		}
		void message() {
			System.out.println("Inner.message()");
			System.out.println("  "+num);
		}
	}
	
	void welcome() {
		System.out.println("Outer.welcome()");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer out = new Outer();
		Inner in = out.new Inner();
		in.message();
		out.welcome();
		
		out.display();
	}

}
