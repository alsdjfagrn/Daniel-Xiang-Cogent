
public class A {
	static int num = 90;

	static class Inner {
		void message() {
			System.out.println("Inner.message()");
			System.out.println("  "+num);
		}
		static void display() {
			System.out.println("Inner.display()");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A.Inner in = new A.Inner();
		in.message();
		
		A.Inner.display();
	}

}
