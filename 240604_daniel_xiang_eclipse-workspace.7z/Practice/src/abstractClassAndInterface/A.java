package abstractClassAndInterface;

public interface A {
	void thing1();
}
