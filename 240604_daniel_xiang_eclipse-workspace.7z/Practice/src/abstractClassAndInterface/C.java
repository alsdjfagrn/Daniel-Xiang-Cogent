package abstractClassAndInterface;

public class C extends B implements A {

	@Override
	public void thing1() {
		// TODO Auto-generated method stub
		System.out.println("C.thing1()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj = new C();
		
		obj.thing1();
		obj.thing2();
	}

}
