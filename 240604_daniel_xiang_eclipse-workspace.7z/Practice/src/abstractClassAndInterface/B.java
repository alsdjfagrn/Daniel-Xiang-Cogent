package abstractClassAndInterface;

public abstract class B {
	void thing2() {
		System.out.println("B.thing2()");
	}
}
