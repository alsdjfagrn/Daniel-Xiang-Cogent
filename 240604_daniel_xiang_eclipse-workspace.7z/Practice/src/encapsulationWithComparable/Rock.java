package encapsulationWithComparable;

public class Rock implements Comparable<Rock> {
	private float mass;

	public Rock(float mass) {
		super();
		this.mass = mass;
	}

	public float getmass() {
		return mass;
	}

	public void setmass(float mass) {
		this.mass = mass;
	}

	@Override
	public int compareTo(Rock o) {
		// TODO Auto-generated method stub
		if (this.mass > o.mass) {
			return 1;
		}
		if (this.mass < o.mass) {
			return -1;
		}
		return 0;
	}
	
}
