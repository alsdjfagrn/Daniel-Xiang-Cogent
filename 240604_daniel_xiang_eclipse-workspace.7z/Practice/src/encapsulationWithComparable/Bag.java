package encapsulationWithComparable;

import java.util.ArrayList;

public class Bag {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rock r1 = new Rock(1234);
		Rock r2 = new Rock(5678);
		System.out.println(r1.compareTo(r2));
		
		/*
		ArrayList<Rock> pile = new ArrayList<Rock>();
		pile.add(new Rock(5738428));
		pile.add(new Rock(54636));
		pile.add(new Rock(67759));
		pile.add(new Rock(78235));
		pile.add(new Rock(846729));
		pile.add(new Rock(3487));
		pile.add(new Rock(15050));
		*/
		  
	}
}
