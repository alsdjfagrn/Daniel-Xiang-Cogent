import java.util.ArrayList;

//Concatenate an arraylist into a string (using a Stream API?)
//Reduce method

public class concatArrayListIntoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Object> al = new ArrayList<Object>();
		String s = "";
		
		for (int i=0; i<10; i++) {
			al.add(i);
		}
		al.add("reigu");
		al.add(true);
		al.add(3.14158269);
		//al.add(al.toString());
		System.out.println(al);
		
		/*
		for (Object o : al) {
			s.concat(o.toString());
		}
		*/
		s = (String) al.stream().reduce("", (string_part, obj) -> string_part+obj.toString());
		//s = (String) al.stream().reduce("", String::concat);
		System.out.println(s);
	}

}
