
public class loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=0; i<10; i++) {
			System.out.println("Hi " + i);
		}
		System.out.println();
		
		for (int i=0; i<10; i+=2) {
			System.out.println("Hi " + i);
		}
		System.out.println();
		
		
		int i=1;
		while (i<=10) {
			System.out.println(i);
			i++;
		}
		System.out.println();
		
		
		i=1;
		do {
			System.out.println(i);
			i++;
		}while (i<1);
	}

}
