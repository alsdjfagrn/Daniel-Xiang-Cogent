
public class welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Cogent University");
		System.out.print("\tTab space test");
		System.out.println(" Test");
		System.out.println("First session of Java training");

		var first = 23;
		var second = 89;
		var total = first + second;
		System.out.println("Total of "+first+" and "+second+" is "+total);
		
		var a = 23;
		var b = 45;
		var c = 34;
		System.out.println("Product of "+a+", "+b+", and "+c+" is "+(a*b*c));

		//Data types in Java
		//1. Primitive
		//		int - Non-decimal numerical vals
		//
		int i = 34;
		int j = 45;
		int sum = i+j;
		System.out.println(sum);
		
		//		byte - Non
		//
		byte i2 = 34;
		byte j2 = 60;
		//byte sum2 = i2+j2;//Java converts to int by default when performing a mathematical operation
		byte sum2 = (byte)(i2+j2);//Typecasting
		System.out.println(sum2);
		
		//		short
		//
		short i3 = 89;
		short j3 = 67;
		short sum3 = (short)(i3+j3);
		System.out.println(sum3);
		
		//		long
		//
		long i4 = 90;
		long j4 = 78;
		long sum4 = i4+j4;//Automatic int-to=long conversion
		System.out.println(sum4);
		short sum5 = (short)(i4+j4);
		System.out.println(sum5);
		
		//	byte<short<int<long
		//
		
		//		float
		//
		float p = 23;//Auto-conversion of int to decimal
		System.out.println(p);
		float q = 22323423515135324l;//Long number literals have 'l' at the end
		System.out.println(q);
		float r = (float)(34.45);//Java floats are doubles by default
		
		//		double
		//
		double x = 34.45;
		double y = 23;
		double sum6 = x+y;
		System.out.println(sum6);

		//		char
		//			size: 2 bytes
		char sign = 'A';
		char sign2 = 65;
		int test = sign;
		
		//		boolean - True/False
		//
		boolean check = 34>23;
		boolean check2 = 90!=90;
		
		
		//
		//2. Non-Primitive
		
		
		//Operators
	}

}
