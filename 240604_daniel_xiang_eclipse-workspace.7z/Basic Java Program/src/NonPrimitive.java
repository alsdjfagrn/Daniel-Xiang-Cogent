
public class NonPrimitive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//All are classes by default
		
		//Object
		/*
		 * Parent of all nonprimitive data types
		 * Can store all types of values
		 * Can't perform operations independently - Cast to do so
		 * */
		Object obj = 23;
		Object obj2 = 34.455f;
		Object obj3 = true;
		Object obj4 = "test";
		System.out.println(obj4);
		
		//String
		//	Immutable
		//		Can't change value
		//	String constant pool
		//	Object declaration
		
		String student = new String("Anvar"); //Object-based initialization
	}

}
