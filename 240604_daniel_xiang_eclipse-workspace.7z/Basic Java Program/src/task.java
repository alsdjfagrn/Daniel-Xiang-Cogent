
public class task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		for (;i<10;) {
			System.out.println(i);
			i++;
		}
	}

}
