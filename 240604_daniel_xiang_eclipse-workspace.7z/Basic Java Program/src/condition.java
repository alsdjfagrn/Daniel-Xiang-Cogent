
public class condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//if
		//else
		//switch
		
		int a = 23;
		int b = 34;
		int c = 678;
		
		System.out.println(a>b?a:b);
		System.out.println(a>b?(a>c?a:c):(b>c?b:c));
		
		if (a>b) {
			if (a>c) {
				System.out.println(a);
			}
			else {
				System.out.println(c);
			}
		}
		else {
			if (b>c) {
				System.out.println(b);
			}
			else {
				System.out.println(c);
			}
		}
		
		//Avoid nesting?
		if (a>b && a>c) {
			System.out.println(a);
		}
		else if (b>a && b>c) {
			System.out.println(b);
		}
		else {
			System.out.println(c);
		}
		
		
		int p=90, q=23, r=34, s=56;
		
		
		int month = 5;
		switch (month) {
			case 1:
				System.out.println("Jan");
				break;
			case 2:
				System.out.println("Feb");
				break;
			case 3:
				System.out.println("Mar");
				break;
			case 4:
				System.out.println("Apr");
				break;
			case 5:
				System.out.println("May");
				break;
			case 6:
				System.out.println("Jun");
				break;
			case 7:
				System.out.println("Jul");
				break;
			case 8:
				System.out.println("Aug");
				break;
			case 9:
				System.out.println("Sep");
				break;
			case 10:
				System.out.println("Oct");
				break;
			case 11:
				System.out.println("Nov");
				break;
			case 12:
				System.out.println("Dec");
				break;
			default:
				System.out.println("invalid month");
		}
	}

}
