
public class StringHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "asdf";
		String b = "qwer";
		String c = new String("asdf");
		
		System.out.println(a==c);
		
		System.out.println(a.equals(c));
	}

}
