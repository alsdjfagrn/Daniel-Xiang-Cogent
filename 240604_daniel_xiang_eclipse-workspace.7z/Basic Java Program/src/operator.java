
public class operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Operator - Symbol that performs operations
		/*
		 * Types
		 * 	Arithmetic
		 * 		+, -, *, /, %
		 * 	Relational
		 * 		>, <, >=, <=, ==, !=
		 * 		Return type: boolean
		 * 	Logical
		 * 		!, &&, ||
		 * 	Assignment
		 * 		=, +=, -=, *=, /=
		 * 	Bitwise
		 * 		DSA?
		 * 		&, |, << (left shift), >> (right shift), ^(XOR)
		 * 	Ternary Operator
		 * 		_?_:_
		 * 		<Bool>?<Run if true>:<Run if false>
		 * */
		
		//Arithmetic
		//	Always returns integer if integers input
		//		Integer division
		System.out.println(34/3);
		System.out.println(34/(float)3);
		System.out.println((float)34/3);
		
		//	Modulo
		System.out.println(23%5);
		
		//Relational
		System.out.println('A'=='a');
		System.out.println('A'==65);
		System.out.println('A'!='B');
		
		//Logical
		System.out.println((23>34) && (90>23));
		System.out.println((23>34) || (90>23));
		
		//Assignment
		int a = 90;
		int b = 78;
		a += b;
		System.out.println(a);
		
		//Bitwise
		int x = 5;//00000101
		int y = 3;//00000011
		System.out.println(x&y);
		
		//Ternary operator
		System.out.println(x>y?x:y);
	}

}
