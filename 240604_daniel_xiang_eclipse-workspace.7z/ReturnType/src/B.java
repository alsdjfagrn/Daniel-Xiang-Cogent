
public final class B {
	
	int num=90;
	
	//Private constructor means the class can't be created from outside the class
	private B() {
		
	}
	
	//Covariant method
	static B object() {
		return new B();
	}
}
