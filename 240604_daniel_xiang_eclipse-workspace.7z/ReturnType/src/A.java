
public class A {
	
	void sum(int a, int b) {
		System.out.println(a+b);
	}
	
	int multi(int a, int b) {
		return a*b;
	}
	
	
	//covariant method
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A o = new A();
		o.sum(12,30);
		System.out.println(o.multi(12, 30));
		
		//Covariant method
		B o2 = B.object();
	}

}
