package DTO;

public class CustomerDetails {
	private int account_no;
	private String name;
	private String email;
	private long phone;
	private int acc_type;
	private long balance;
	private String password;
	
	public CustomerDetails() {
		
	}
	
	public CustomerDetails(int account_no, String name, String email, long phone, int acc_type, long balance, String password) {
		super();
		this.account_no = account_no;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.acc_type = acc_type;
		this.balance = balance;
		this.password = password;
	}
	
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public int getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(int acc_type) {
		this.acc_type = acc_type;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "CustomerDetails [account_no=" + account_no + ", name=" + name + ", email=" + email + ", phone=" + phone
				+ ", acc_type=" + acc_type + ", balance=" + balance + ", password=" + password + "]";
	}
	
	
}
