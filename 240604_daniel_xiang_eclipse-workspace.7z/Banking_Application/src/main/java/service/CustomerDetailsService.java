package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.CustomerDetails;
import repository.CustomerDetailsRepository;
import repository.DepositRepo;
import repository.ConnectionRepo;

public class CustomerDetailsService implements CustomerDetailsRepository, ConnectionRepo, DepositRepo {

	Connection conn = null;
	PreparedStatement s = null;
	ResultSet result = null;
	
	public CustomerDetailsService() throws Exception {
		connect_to_db();
	}
	
	@Override
	public void create_new_account(CustomerDetails customer) throws SQLException {
		// TODO Auto-generated method stub
		System.out.print("Inserting customer details into database...");
		
		s = conn.prepareStatement(""
				+ "INSERT INTO Customer(account_no, name, email, phone, acc_type, balance, password) "
				+ "VALUES(?,?,?,?,?,?,?);");
		s.setInt(1, customer.getAccount_no());
		s.setString(2, customer.getName());
		s.setString(3, customer.getEmail());
		s.setLong(4, customer.getPhone());
		s.setInt(5, customer.getAcc_type());
		s.setLong(6, customer.getBalance());
		s.setString(7, customer.getPassword());
		
		s.executeUpdate();
		
		System.out.println(" Done.");
	}

	@Override
	public void connect_to_db() throws Exception{
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Banking_App","root","Fhsd180669@");
		System.out.println("Connected.");
	}

	@Override
	public void deposit(int account_no, long amount) throws Exception {
		// TODO Auto-generated method stub
		long balance;
		
		s = conn.prepareStatement(""
				+ "SELECT balance "
				+ "FROM Customer "
				+ "WHERE account_no=?;");
		s.setLong(1, account_no);
		
		result = s.executeQuery();
		result.next();
		balance = result.getLong(1);
		balance += amount;
		
		s = conn.prepareStatement(""
				+ "UPDATE Customer "
				+ "SET balance=? "
				+ "WHERE account_no=?;");
		s.setLong(1, balance);
		s.setLong(2, account_no);
		System.out.println(s);
		s.executeUpdate();
	}
}
