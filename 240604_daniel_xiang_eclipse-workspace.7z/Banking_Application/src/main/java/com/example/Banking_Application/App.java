package com.example.Banking_Application;

import java.util.Random;
import java.util.Scanner;

import DTO.CustomerDetails;
import service.CustomerDetailsService;

/**
 * Application entry point
 *
 */
public class App 
{
	static {
		System.out.println("Starting bank app...");
	}
	
	Scanner input = null;

	CustomerDetails customer = null;
	CustomerDetailsService service_details = null;
	
	App() throws Exception {
		input = new Scanner(System.in);
		customer = new CustomerDetails();
		service_details = new CustomerDetailsService();
	}
	
	void create_account() throws Exception {
		String name;
		String email;
		long phone;
		Random random = new Random();
		
		System.out.print("Input name: ");
		name = input.nextLine();
		System.out.println();
		System.out.print("Input email: ");
		email = input.nextLine();
		System.out.println();
		System.out.print("Input phone number: ");
		phone = input.nextLong();
		input.nextLine();
		System.out.println();
		System.out.print("Input password: ");
		String password = input.nextLine();
		System.out.println();
		
		customer.setName(name);
		customer.setEmail(email);
		customer.setPhone(phone);
		customer.setPassword(password);
		customer.setAccount_no(random.nextInt());

		account_type();
		
		customer.setBalance(0);
		
		service_details.create_new_account(customer);
	}
	
	void account_type() {
		boolean finished = true;
		int choice;
		String c;
		
		do {
			System.out.println(""
					+ "Select an option below:\n"
					+ "  1 - Savings\n"
					+ "  2 - Salary\n"
					+ "  3 - Current\n"
					+ "  4 - Quit\n");
			choice = input.nextInt();//Get choice from user
			input.nextLine();
			
			switch(choice) {
				case 1:
					System.out.println("Savings account selected.");
					System.out.println("Maintain $1000 balance.");
					System.out.println("Checkbook & visa card included.");
					System.out.print("Would you like to proceed? [y/n]: ");
					c = input.next();
					System.out.println();
					if (c.equalsIgnoreCase("y")) {
						customer.setAcc_type(1);
					}
					else {
						finished = false;
					}
					break;
				case 2:
					System.out.println("Salary account selected.");
					System.out.println("Maintain $0 balance.");
					System.out.println("Visa card included.");
					System.out.print("Would you like to proceed? [y/n]: ");
					c = input.next();
					System.out.println();
					if (c.equalsIgnoreCase("y")) {
						customer.setAcc_type(2);
					}
					else {
						finished = false;
					}
					break;
				case 3:
					System.out.println("Current account selected.");
					System.out.println("Checkbook & Mastercard included.");
					System.out.println("Credit card eligible.");
					System.out.print("Would you like to proceed? [y/n]: ");
					c = input.next();
					System.out.println();
					if (c.equalsIgnoreCase("y")) {
						customer.setAcc_type(3);
					}
					else {
						finished = false;
					}
					break;
				case 4:
					System.out.println("Ending program.");
					finished = true;
					break;
				default:
					System.out.println("Invalid input.");
					finished = false;
			}
		} while (finished == false);
	}
	
	void select_option() throws Exception {
		boolean finished = false;
		int choice;
		int account_no;
		long quantity;
		
		do {
			System.out.println(""
					+ "Select an option below:\n"
					+ "  1 - Create account\n"
					+ "  2 - Deposit\n"
					+ "  3 - Withdraw\n"
					+ "  4 - Quit\n");
			choice = input.nextInt();//Get choice from user
			input.nextLine();
			
			switch(choice) {
				case 1:
					create_account();
					break;
				case 2:
					System.out.print("Enter account no: ");//1913657485
					account_no = input.nextInt();
					input.nextLine();
					System.out.print("Enter amount to deposit: ");
					quantity = input.nextLong();
					input.nextLine();
					service_details.deposit(account_no, quantity);
					break;
				case 3:
					break;
				case 4:
					System.out.println("Ending program.");
					finished = true;
					break;
				default:
					System.out.println("Invalid input.");
					finished = false;
			}
		} while (finished == false);
	}
    
	public static void main( String[] args ) throws Exception
    {
        App a = new App();
		a.select_option();
    }
}
