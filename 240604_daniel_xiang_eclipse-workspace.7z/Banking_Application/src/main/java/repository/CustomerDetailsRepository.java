package repository;

import java.sql.SQLException;

import DTO.CustomerDetails;

public interface CustomerDetailsRepository {
	void create_new_account(CustomerDetails customer) throws SQLException;
}
