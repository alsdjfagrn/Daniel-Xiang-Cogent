package repository;

public interface DepositRepo {
	void deposit(int account_no, long amount) throws Exception;
}
