package repository;

public interface ConnectionRepo {
	void connect_to_db() throws Exception;
}
