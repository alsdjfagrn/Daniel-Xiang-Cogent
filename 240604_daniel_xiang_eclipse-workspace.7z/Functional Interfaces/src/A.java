import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.BiPredicate;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer> predicate = (num) -> {
			if (num%2==0) {
				return true;
			}
			return false;
		};
		System.out.println(predicate.test(91));
		
		Consumer <String> consumer = (name) -> {
			System.out.println(name);
		};
		consumer.accept("asdf");
		
		Function<Integer, String> fun = (num) -> {
			if (num%2==0) {
				return "Even";
			}
			return "Odd";
		};
		System.out.println(fun.apply(100));
		
		BiPredicate<Integer, Integer> bp = (num1, num2) -> {
			if (num1>num2) {
				return true;
			}
			return false;
		};
		System.out.println(bp.test(23, 34));
		
		BiConsumer<Integer, Integer> bc = (num1, num2) -> {
			if (num1>num2) {
				System.out.println("num1>num2");
			}
			else {
				System.out.println("num1<=num2");
			}
		};
		bc.accept(1,2);
		
		BiFunction<Integer, Integer, Integer> bf = (n1, n2) -> {
			if (n1>n2) {
				return n1;
			}
			return n2;
		};
		System.out.println(bf.apply(1, 2));
	}

}
