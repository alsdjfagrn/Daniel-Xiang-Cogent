package com.example.AnnotationConfig;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class School {
	@Autowired
	private Education e;
	
	@Autowired
	private Project p;
	
	//Constructor injection
//	public School(Education e) {
//		super();
//		this.e = e;
//	}
	
	void caller() {
		System.out.println("School.caller()");
		System.out.println("  School.e.message()");
		e.message();
	}
	
	/*@Bean
	public Education edu() {
		return new Education();
	}*/
}
