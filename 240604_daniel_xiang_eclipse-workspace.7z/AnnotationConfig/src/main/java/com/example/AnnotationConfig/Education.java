package com.example.AnnotationConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class Education {
	void message() {
		System.out.println("Education.message()");
	}
	
	@Bean
	public Project project() {
		return new Project();
	}
}
