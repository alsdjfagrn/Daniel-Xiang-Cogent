package com.example.AnnotationConfig;

public class Project {
	void test() {
		System.out.println("Project.test()");
	}
}
