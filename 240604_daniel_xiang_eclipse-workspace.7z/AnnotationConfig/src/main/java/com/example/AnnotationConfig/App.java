package com.example.AnnotationConfig;
//AKA annotation XML configuration

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("springconfig.xml");
    	
        Education e = context.getBean(Education.class);
        e.message();
        
        School s = context.getBean(School.class);
        s.caller();
    }
}
