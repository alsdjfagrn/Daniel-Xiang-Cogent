//Reference to static method
interface Caller {
	void call();
}

public class A {

	static void message() {
		System.out.println("message()");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Caller c = A::message;
		c.call();
	}

}
