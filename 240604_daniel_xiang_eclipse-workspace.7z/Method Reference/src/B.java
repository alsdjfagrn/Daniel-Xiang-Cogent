//Reference to instance (non-static) method
//	Create object

interface Caller2 {
	void call();
}

public class B {
	
	void message() {
		System.out.println("message()");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Caller2 c = new B()::message;
		c.call();
	}

}
