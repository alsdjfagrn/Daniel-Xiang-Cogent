interface Caller3 {
	void call();
}

public class C {
	
	C() {
		System.out.println("C()");
	}
	
	void message() {
		System.out.println("message()");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Caller3 c = C::new;
		c.call();
		
		/*
		Caller3 c2 = new Caller3() {

			@Override
			public void call() {
				// TODO Auto-generated method stub
				new C();
			}
			
		};
		c2.call();
		*/
	}

}
