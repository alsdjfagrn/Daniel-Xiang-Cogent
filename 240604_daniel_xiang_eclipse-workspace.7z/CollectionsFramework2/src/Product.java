
public class Product implements Comparable {
	private int pid;
	private String pName;
	private int pPrice;
	private boolean inStock;
	private float rate;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpPrice() {
		return pPrice;
	}
	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}
	public boolean isInStock() {
		return inStock;
	}
	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public Product(int pid, String pName, int pPrice, boolean inStock, float rate) {
		super();
		this.pid = pid;
		this.pName = pName;
		this.pPrice = pPrice;
		this.inStock = inStock;
		this.rate = rate;
	}
}
