import java.util.ArrayList;
import java.util.HashMap;


public class Hash_Map_Test_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Object> m1 = new HashMap<String, Object>();
		HashMap<String, Object> m2 = new HashMap<String, Object>();
		HashMap<String, Object> m3 = new HashMap<String, Object>();
		m1.put("name", "Ravi");
		m2.put("name", "Jayant");
		m3.put("name", "Varun");
		
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		data.add(m1);
		data.add(m2);
		data.add(m3);
		
		for (HashMap<String, Object> m : data) {
			//
		}
	}

}
