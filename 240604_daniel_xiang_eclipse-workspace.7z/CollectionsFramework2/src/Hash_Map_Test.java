import java.util.HashMap;


public class Hash_Map_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("name", map);
	}

}
