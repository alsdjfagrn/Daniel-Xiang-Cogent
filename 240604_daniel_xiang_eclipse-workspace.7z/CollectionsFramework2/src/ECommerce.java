import java.util.Collections;
import java.util.ArrayList;
public class ECommerce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ArrayList
	}

}
