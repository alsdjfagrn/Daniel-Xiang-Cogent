package com.example.JDBC2;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class App 
{
	//Connection responsible for connecting with database
	Connection conn = null;
	
	//Statement used to execute sql queries in SQL server
	Statement stm = null;
	
	//Used to insert lots of data at once
	PreparedStatement preStatement = null;
	
	App() {
		//(<DB path>, <username>, <password>)
		try {
			String host = "jdbc:mysql://localhost:3306/";
			String database = "ShopDB";
			
			Class.forName("com.mysql.cj.jdbc.Driver");//Register Driver class in project
			conn = DriverManager.getConnection(host+database, "root", "Fhsd180669@");//Build connection
			System.out.println("Connected to "+host+database);
			
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	void fetchAllData() throws Exception{
		String query = ""
				+ "SELECT * "
				+ "FROM Records";
		stm = conn.createStatement();
		
		//Execute query & return in ResultSet
		ResultSet results = stm.executeQuery(query);
		
		while (results.next()) {
			//SQL indexes start at 1
			System.out.println(results.getInt(1)+results.getString(2)+results.getInt(3));
		}
	}
	
	void insertData(String name, int purchase, String email, String password, int phone) throws SQLException {
		//Build statement
		String query = ""
				+ "INSERT INTO Records(name, purchase, email, password, phone) "
				+ "VALUES(?,?,?,?,?);";
		preStatement = conn.prepareStatement(query);
		preStatement.setString(1, name);
		preStatement.setInt(2, purchase);
		preStatement.setString(3, email);
		preStatement.setString(4, password);
		preStatement.setInt(5, phone);
		
		//Execute statement
		preStatement.executeUpdate();
	}

	void fetchSingleData(String email) throws SQLException {
		preStatement = conn.prepareStatement(""
				+ "SELECT * "
				+ "FROM Records "
				+ "WHERE email=?;");
		preStatement.setString(1, email);
		ResultSet results = preStatement.executeQuery();
		results.next();
		System.out.println(results.getInt(1)+results.getString(2)+results.getInt(3)+results.getString(4)+results.getString(5)+results.getInt(6));
	}
	Record fetchSingleData2(String email) throws SQLException {
		preStatement = conn.prepareStatement(""
				+ "SELECT * "
				+ "FROM Records "
				+ "WHERE email=?;");
		preStatement.setString(1, email);
		ResultSet results = preStatement.executeQuery();
		results.next();
		return new Record(
				results.getInt(1),
				results.getString(2),
				results.getInt(3),
				results.getString(4),
				results.getString(5),
				results.getInt(6));
	}
	
	void updateRecord(String email) throws SQLException {
		Record rec = fetchSingleData2(email);
		rec.setPhone(123123123);
		
		String query = ""
				+ "UPDATE Records "
				+ "SET phone=? "
				+ "WHERE email=?;";
		preStatement = conn.prepareStatement(query);
		preStatement.setInt(1, rec.getPhone());
		preStatement.setString(2, rec.getEmail());
		
		//System.out.println(preStatement);
		
		preStatement.executeUpdate();
	}
	
    public static void main( String[] args ) throws Exception {
        App app = new App();
        
        //app.fetchAllData();
        //app.insertData("Ravi", 50000, "ravi@gmail.com", "asdf", 238593649);
        app.fetchSingleData("ravi@gmail.com");
        app.updateRecord("ravi@gmail.com");
        app.fetchSingleData("ravi@gmail.com");
    }
}
