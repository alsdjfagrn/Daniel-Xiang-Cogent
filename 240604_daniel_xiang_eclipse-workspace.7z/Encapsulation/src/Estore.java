
public class Estore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		String[] product = {
				"Remote",
				"Phone",
				"Table",
				"Laptop"
		};
		String[] productDetail = {
				"AC Remote",
				"Iphone",
				"Wooden table",
				"Dell laptop"
		};
		float[] productPrice = {
			100,
			2000,
			150,
			4000
		};
		//Too complicated & messy
		*/
		Product p1 = new Product(0, "Remote", "AC remote", 100);
		Product p2 = new Product(1, "Phone", "Iphone", 2000);
		Product p3 = new Product(2, "Table", "Wooden table", 150);
		Product p4 = new Product(3, "Laptop", "Dell laptop", 4000);
		
		Product[] products = {p1, p2, p3, p4};
		for (Product p:products) {
			System.out.println(
				(p.getId())+" - "+
				(p.getName())+" - "+
				(p.getDetail())+" - "+
				(p.getPrice()));
		}
		for (Product p:products) {
			System.out.println(p.toString());
		}
		for (int i=1; i<4; i++) {
			System.out.println(products[i-1].compareTo(products[i]));
		}
	}

}
