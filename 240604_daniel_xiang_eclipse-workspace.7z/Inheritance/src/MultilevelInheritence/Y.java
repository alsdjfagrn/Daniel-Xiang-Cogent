package MultilevelInheritence;

public class Y extends Z{
	Y() {
		this(89);
		System.out.println("Y constructor");
	}
	Y(int num) {
		super();//Parent class constructor
		System.out.println("Y param. constructor called: "+(num));
	}
}
