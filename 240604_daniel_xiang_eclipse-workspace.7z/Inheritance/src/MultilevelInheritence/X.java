package MultilevelInheritence;

public class X extends Y{
	
	X() {
		//super()
		System.out.println("X default constructor");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		X x = new X();
	}

}
