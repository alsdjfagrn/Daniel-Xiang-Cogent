package MultilevelInheritence;

public class Z {
	Z() {
		this(23);
		System.out.println("Z default constructor");
	}
	Z(int num) {
		System.out.println("Z param. constructor: "+(num));
	}
}
