
public class B {
	
	B() {
		System.out.println("B constructor called");
	}
	
	B (int a) {
		this();
		System.out.println(a);
	}
	
	void Task() {
		System.out.println("Task() in B called");
	}
}
