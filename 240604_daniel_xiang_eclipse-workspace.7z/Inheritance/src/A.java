
public class A extends B{
	
	void welcome() {
		System.out.println("welcome() called");
	}
	
	A () {
		this(23);
		System.out.println("A default constructor called");
	}
	A(int a) {
		super(a);
		System.out.println("A parameterized constructor called");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A o = new A();
		o.welcome();
		o.Task();
	}

}
