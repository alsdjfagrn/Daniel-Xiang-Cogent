package Task;

public class P extends Q{
	P() {
		super();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P p = new P();
	}

}
