package Task;

public class Q extends R{
	Q() {
		super(78);
	}
	Q(int num) {
		System.out.println("Q constr "+(num));
	}
}
