package Task;

public class R {
	R() {}
	R(int num) {
		this(12, 13);
		System.out.println("R param. constructor: "+(num));
	}
	R(int a, int b) {
		System.out.println("R 2 param constr "+(a)+" "+(b));
	}
}
