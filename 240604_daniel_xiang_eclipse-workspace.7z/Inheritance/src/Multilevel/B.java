package Multilevel;

public class B extends C {
	int num = 45;
	
	B() {
		System.out.println(num);
	}
}
