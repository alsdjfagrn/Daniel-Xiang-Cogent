package Multilevel;

public class A extends B{
	
	int num = 90;
	
	void print() {
		System.out.println(num);
		System.out.println(super.num);
	}
	
	public static void main(String[] args) {
		A o = new A();
		System.out.println(o.num);
		o.print();
	}
}
