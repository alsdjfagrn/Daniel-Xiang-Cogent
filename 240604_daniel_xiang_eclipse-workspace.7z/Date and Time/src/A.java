import java.time.LocalDateTime;
import java.util.Date;
import java.util.Calendar;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d = new Date();
		System.out.println(d);
		
		long ms = System.currentTimeMillis();
		System.out.println(ms);
		
		Date d2 = new Date(ms);
		System.out.println(d2);
		
		
		java.sql.Date date = new java.sql.Date(ms);
		System.out.println(date);
		
		
		String str = "2024-05-28";
		java.sql.Date date2 = java.sql.Date.valueOf(str);
		System.out.println(date2);
		
		
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println(ldt);
		System.out.println(ldt.getHour());
		System.out.println(ldt.getMinute());
		System.out.println(ldt.toLocalDate());
		
		
		Calendar c = Calendar.getInstance();
		c.set(Calendar.MONTH, 5);//Starts at 0 for Jan.
		c.set(Calendar.DATE, 28);
		c.set(Calendar.YEAR, 2024);
		
		Date d3 = c.getTime();
		System.out.println(d3);
		
		
		System.out.println(Math.PI);
		System.out.println(Math.pow(13, 13));
		System.out.println(Math.sqrt(19));
		System.out.println(Math.sin(1));
		System.out.println();
	}

}
