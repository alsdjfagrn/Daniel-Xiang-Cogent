package leskovsSubstitution;

//Implementing only interfaces with used functions
//No unused/invalid functions - avoid redundant code
public class Instagram implements SocialVideoCallManager, SocialMedia {

	@Override
	public void chatWithFriends() {
		// TODO Auto-generated method stub

	}

	@Override
	public void publishPost() {
		// TODO Auto-generated method stub

	}

	@Override
	public void groupVideoCall() {
		// TODO Auto-generated method stub

	}

}
