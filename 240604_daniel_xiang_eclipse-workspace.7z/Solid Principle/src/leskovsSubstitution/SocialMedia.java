package leskovsSubstitution;

public interface SocialMedia {
	//WhatsApp, Facebook, Instagram
	public abstract void chatWithFriends();
	
	//Facebook, Instagram
	public abstract void publishPost();
	
	//WhatsApp, Facebook
	public abstract void groupVideoCall();
}
