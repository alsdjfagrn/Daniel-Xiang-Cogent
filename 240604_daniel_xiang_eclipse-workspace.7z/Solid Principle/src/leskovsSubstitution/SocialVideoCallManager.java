package leskovsSubstitution;

public interface SocialVideoCallManager {

}
