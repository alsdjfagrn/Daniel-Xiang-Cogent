package leskovsSubstitution;

public interface PostManager {

}
