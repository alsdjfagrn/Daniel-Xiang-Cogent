package singleResponsibility;

public class LoanService {
	void getLoanInfo() {
		System.out.println("LoanService.getLoanInfo()");
		if (loanType.equals("home")) {
			
		}
		if (loanType.equals("personal")) {
			
		}
		if (loanType.equals()) {
			
		}
	}
}
