package singleResponsibility;

public class BankService {
	long deposit(long amount, String accID) {
		return 0;
	}
	long withdraw(long amount, String accID) {
		return 0;
	}
}
