package singleResponsibility;

public class PrinterService {
	
	void printPassbook() {
		System.out.println("PrinterService.printPassbook()");
	}
}
