package singleResponsibility;

public class NotificationService {
	void sendOTP(String email) {
		if (email.equals("ravi@gmail.com")) {
			
		}
	}
}
