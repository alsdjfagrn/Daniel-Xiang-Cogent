package dependencyInversion;

public interface BankCard {
	void isPresent();
}
