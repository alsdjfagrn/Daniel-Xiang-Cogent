package openAndClose;

public class EmailNotificationService implements NotificationService {

	@Override
	public void sendOTP(String email) {
		// TODO Auto-generated method stub

	}
	
	void validate() {
		
	}
}
