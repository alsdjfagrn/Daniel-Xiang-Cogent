package openAndClose;

public interface NotificationService {
	public void sendOTP(String email);
}
