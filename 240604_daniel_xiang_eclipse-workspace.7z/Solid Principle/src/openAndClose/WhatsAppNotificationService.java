package openAndClose;

public class WhatsAppNotificationService implements NotificationService {

	@Override
	public void sendOTP(String email) {
		// TODO Auto-generated method stub

	}

}
