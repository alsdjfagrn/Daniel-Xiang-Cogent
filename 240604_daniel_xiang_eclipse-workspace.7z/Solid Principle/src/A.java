
public class A {
	
	/*
	 * Single responsibility
	 * Open and close
	 * Leskov's substitution
	 * Interface aggregation
	 * Dependency inversion
	 */
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
