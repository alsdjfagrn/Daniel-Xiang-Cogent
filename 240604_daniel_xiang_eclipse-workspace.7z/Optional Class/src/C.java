import java.util.Optional;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] name = new String[5];
		name[2] = "Jordan";
		for (String s : name) {
			//Optional<String> checkNull = Optional.ofNullable(s);

			//String result = Optional.ofNullable(s).orElseThrow();
			//System.out.println(result);

			//Optional<String> checkNull = Optional.empty();
			
			Optional<String> checkNull = Optional.of(s);
			
			checkNull.ifPresentOrElse(System.out::println, ()->System.out.println(data));
			
		}
	}

}
