import java.util.Optional;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Without Optional
		//String[] name = new String[5];
		//System.out.println(name[0]);
		//System.out.println(name[0].toLowerCase());
		
		
		//With Optional
		String[] n = new String[5];
		Optional<String> checkNull = Optional.ofNullable(n[0]);
		if (checkNull.isPresent()) {
			System.out.println(n[0].toLowerCase());
		}
		else {
			System.out.println("str not found");
		}
	}

}
