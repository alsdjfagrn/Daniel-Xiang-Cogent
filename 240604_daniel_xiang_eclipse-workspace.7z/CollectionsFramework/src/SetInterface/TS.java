package SetInterface;

import java.util.TreeSet;

public class TS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Integer> hs2 = new TreeSet<Integer>();
		hs2.add(23);
		hs2.add(634);
		hs2.add(547);
		hs2.add(383);
		hs2.add(49);
		hs2.add(68448);
		hs2.add(2);
		hs2.add(5894);
		System.out.println(hs2);
		for (Object o : hs2) {
			System.out.println("  "+o);
		}
	}

}
