package SetInterface;

import java.util.HashSet;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet hs = new HashSet();

		hs.add(23);
		hs.add(true);
		hs.add("Ravi");
		hs.add(23.34f);
		hs.add(43.34534);
		hs.add(65416528);
		
		System.out.println(hs);
		
		for (Object o : hs) {
			System.out.println("  "+o);
		}
		
		
		HashSet<Integer> hs2 = new HashSet();
		hs2.add(23);
		hs2.add(634);
		hs2.add(547);
		hs2.add(383);
		hs2.add(49);
		hs2.add(68448);
		hs2.add(2);
		hs2.add(5894);
		System.out.println(hs2);
		for (Object o : hs2) {
			System.out.println("  "+o);
		}
	}

}
