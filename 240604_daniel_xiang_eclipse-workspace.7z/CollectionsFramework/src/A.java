import java.util.ArrayList;
import java.util.Iterator;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Object> al = new ArrayList<Object>();

		al.add(23);
		al.add(true);
		al.add("Ravi");
		al.add(23.34f);
		al.add(43.34534);
		al.add(65416528);
		System.out.println(al);
		
		System.out.println("Fetching data with iterator interface");
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println("  "+itr.next());
		}
		
		System.out.println("Fetching data by for each");
		for (Object obj : al) {
			System.out.println("  "+obj);
		}
		
		System.out.println("Fetching data by index");
		for (int i=0; i<al.size(); i++) {
			System.out.println("  "+al.get(i));
		}
	}

}
