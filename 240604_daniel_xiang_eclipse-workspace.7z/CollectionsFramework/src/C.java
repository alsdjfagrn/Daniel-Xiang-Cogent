import java.util.LinkedList;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList al = new LinkedList();
		
		al.add(23);
		al.add(true);
		al.add("Ravi");
		al.add(23.34f);
		al.add(43.34534);
		al.add(65416528);
		
		//Only non-primitive data types allowed; use wrapper classes
		LinkedList<Integer> al2 = new LinkedList<Integer>();
		al2.add(1234);
		al2.add(356);
		al2.add(689);
		
		//Add all?
		//	Concatenate
		al.addAll(al2);
		
		//al.clear()
		
		LinkedList al_clone = (LinkedList)al.clone();
		
		System.out.println(al_clone.contains(1234)?"T":"F");
		
		
		
		System.out.println(al_clone.indexOf(1234));
		
		//al_clone.clear()
		al_clone.isEmpty();
		al_clone.remove(6);
		
		al.set(6, 12345);//Rplace data in index

		for (Object o : al) {
			System.out.println("  "+o);
		}

		al2.removeIf((a) -> a%2==0);
		System.out.println(al2);
		for (Object o : al2) {
			System.out.println("  "+o);
		}
	}

}
